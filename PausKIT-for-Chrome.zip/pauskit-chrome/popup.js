const APP = "https://pause-diary.pages.dev/";
const d = new Date();
document.getElementById("date").textContent = d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
fetch(APP + "news.json", { cache: "no-cache" }).then((r) => r.json()).then((n) => {
  const days = n.days || {};
  const s = days[iso] || days[Object.keys(days).sort().pop()];
  document.getElementById("news").textContent = s ? (s.word ? s.word.word + " · " : "") + s.headline : "Open PausKIT to see today's page.";
}).catch(() => { document.getElementById("news").textContent = "Open PausKIT to see today's page."; });
document.getElementById("open").addEventListener("click", () => { chrome.tabs.create({ url: APP }); window.close(); });
